#include <stdio.h>
#include <string.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

#define MAX_LINE_LENGTH 100
#define MAX_PRODUCTS 100

typedef struct {
    char description[MAX_LINE_LENGTH];
    char name[50];
    int quantity;
    int weight;  // Now always stored in grams
    float totalValue;
} Product;

void createReceiptFile(char *filename) {
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);

    sprintf(filename, "../management/control/receipt-%02d-%02d-%04d-%02d-%02d-%02d.txt",
            tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900,
            tm.tm_hour, tm.tm_min, tm.tm_sec);
}

void addProductToFile(const Product *product, const char *filename) {
    FILE *file = fopen(filename, "a");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo para adicionar produto.\n");
        return;
    }

    // Quando o produto tem peso
    if (product->weight > 0) {
        fprintf(file, "Produto: %sPeso: %dg\nValor: R$%.2f\n\n",
                product->description, product->weight, product->totalValue);
    }
    // Quando o produto tem quantidade
    else {
        fprintf(file, "Produto: %s\n", product->description);
        fprintf(file, "Quantidade: %d\n", product->quantity);
        fprintf(file, "Valor: R$%.2f\n\n", product->totalValue);
    }

    fclose(file);
}

int readProductsFromFile(const char *filename, Product *products) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        return 0;
    }

    char line[MAX_LINE_LENGTH];
    int productCount = 0;
    Product currentProduct = {0};
    int lineCount = 0;

    while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
        if (strncmp(line, "Produto: ", 9) == 0) {
            if (lineCount > 0) {
                products[productCount++] = currentProduct;
                memset(&currentProduct, 0, sizeof(Product));
            }
            strncpy(currentProduct.description, line + 9, MAX_LINE_LENGTH - 9);
            lineCount = 1;
        } else if (strstr(line, "Peso: ") != NULL) {
            sscanf(line, "Peso: %dg", &currentProduct.weight);
        } else if (strstr(line, "Quantidade: ") != NULL) {
            sscanf(line, "Quantidade: %d", &currentProduct.quantity);
        } else if (strstr(line, "Valor: ") != NULL) {
            sscanf(line, "Valor: R$%f", &currentProduct.totalValue);
            products[productCount++] = currentProduct;
            memset(&currentProduct, 0, sizeof(Product));
            lineCount = 0;
        }
    }

    fclose(file);
    return productCount;
}

void rewriteProductFile(const char *filename, const Product *products, int productCount) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Erro ao reescrever arquivo de produtos.\n");
        return;
    }

    for (int i = 0; i < productCount; i++) {
        if (products[i].weight > 0) {
            fprintf(file, "Produto: %sPeso: %dg\nValor: R$%.2f\n\n",
                    products[i].description, products[i].weight, products[i].totalValue);
        } else {
            fprintf(file, "Produto: %sQuantidade: %d\nValor: R$%.2f\n\n",
                    products[i].description, products[i].quantity, products[i].totalValue);
        }
    }

    fclose(file);
}

int searchProduct(char *filename, char *code, FILE **receipt, char *receiptFilename, Product *products, int *productCount) {
    FILE *file = fopen(filename, "r");
    char line[MAX_LINE_LENGTH];
    const int MAX_WEIGHT = 25000; // Maximum weight in grams

    if (file == NULL) {
        printf("Erro ao abrir o arquivo de produtos.\n");
        return 0;
    }

    int found = 0;
    while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
        if (strncmp(line, code, 4) == 0) {
            found = 1;

            if (*receipt == NULL) {
                createReceiptFile(receiptFilename);
                *receipt = fopen(receiptFilename, "w");
                if (*receipt == NULL) {
                    printf("Erro ao criar o arquivo de recibo.\n");
                    fclose(file);
                    return 0;
                }
                printf("\nArquivo de recibo criado: %s\n\n", receiptFilename);
            }

            printf("Produto: %s", line + 5);

            float valor;
            sscanf(strrchr(line, 'R'), "R$%f", &valor);

            Product newProduct = {0};
            strncpy(newProduct.description, line + 5, MAX_LINE_LENGTH);

            if (strstr(line, "kilo") != NULL) {
                int peso;
                while (1) {
                    printf("Insira o peso em gramas: ");
                    if (scanf("%d", &peso) == 1) {
                        if (peso > MAX_WEIGHT) {
                            printf("Peso acima do limite da balan�a (25kg).\n");
                            while (getchar() != '\n'); // Clear input buffer
                            continue;
                        }
                        if (peso <= 0) {
                            printf("Peso inv�lido. � necess�rio que seja maior que 0g.\n");
                            while (getchar() != '\n'); // Clear input buffer
                            continue;
                        }
                        break;
                    } else {
                        printf("Entrada inv�lida. Por favor, insira um n�mero.\n");
                        while (getchar() != '\n');
                    }
                }
                float valorTotal = (valor / 1000) * peso;  // valor is per kilo, converting to per gram
                printf("Peso: %dg\nValor: R$%.2f\n", peso, valorTotal);

                newProduct.weight = peso;
                newProduct.totalValue = valorTotal;
            } else {
                int quantidade;
                while (1) {
                    printf("Insira a quantidade: ");
                    if (scanf("%d", &quantidade) == 1) {
                        if (quantidade <= 0) {
                            printf("Quantidade inv�lida. Por favor, insira um n�mero maior que zero.\n");
                            while (getchar() != '\n');
                            continue;
                        }
                        break;
                    } else {
                        printf("Entrada inv�lida. Por favor, insira um n�mero.\n");
                        while (getchar() != '\n');
                    }
                }
                float valorTotal = valor * quantidade;
                printf("Quantidade: %d\nValor: R$%.2f\n", quantidade, valorTotal);

                newProduct.quantity = quantidade;
                newProduct.totalValue = valorTotal;
            }

            if (*productCount < MAX_PRODUCTS) {
                products[*productCount] = newProduct;
                (*productCount)++;
                addProductToFile(&newProduct, receiptFilename);
            }
            break;
        }
    }

    if (!found) {
        printf("C�digo do produto n�o encontrado.\n");
    }

    fclose(file);
    return found;
}

void printProducts(Product *products, int productCount) {
    printf("\nProdutos comprados:\n");
    for (int i = 0; i < productCount; i++) {
        if (products[i].weight > 0) {
            printf("%d. Descri��o: %sPeso: %dg\nValor: R$%.2f\n\n",
                    i + 1, products[i].description, products[i].weight, products[i].totalValue);
        } else {
            printf("%d. Descri��o: %sQuantidade: %d\nValor: R$%.2f\n\n",
                    i + 1, products[i].description, products[i].quantity, products[i].totalValue);
        }
    }
}

// [Rest of the code remains unchanged as it doesn't involve weight handling]

void removeProduct(Product *products, int *productCount, int index, const char *filename) {
    if (index < 0 || index >= *productCount) {
        printf("�ndice inv�lido.\n");
        return;
    }

    // Remove the product from the array
    for (int i = index; i < *productCount - 1; i++) {
        products[i] = products[i + 1];
    }
    (*productCount)--;

    // Rewrite the file with updated products
    rewriteProductFile(filename, products, *productCount);

    printf("Produto removido com sucesso.\n");
}

int verifyCredentials() {
    const char *ID = "123456";
    const char *password = "1234";
    char inputID[10];
    char inputPassword[10];
    int attempts = 0;

    while (attempts < 3) {
        printf("Insira o ID: ");
        scanf("%s", inputID);
        printf("Insira a senha: ");

        int i = 0;
        char ch;
        while ((ch = getch()) != '\r') {
            if (ch == '\b') {
                if (i > 0) {
                    printf("\b \b");
                    i--;
                }
            } else {
                inputPassword[i++] = ch;
                printf("*");
            }
        }
        inputPassword[i] = '\0';
        printf("\n");

        if (strcmp(inputID, ID) == 0 && strcmp(inputPassword, password) == 0) {
            return 1;
        } else {
            printf("Credenciais incorretas. Tente novamente.\n");
            attempts++;
        }
    }
    printf("N�mero m�ximo de tentativas atingido. A��o cancelada.\n");
    return 0;
}

float sum(Product *products, int productCount) {
    float total = 0.0;
    for (int i = 0; i < productCount; i++) {
        total += products[i].totalValue;
    }
    return total;
}

void showHelp() {
    printf("\nComandos dispon�veis:\n");
    printf("Escreva 'cancelar': Exibe a lista de produtos comprados e permite a exclus�o de um item.\n");
    printf("Escreva 'soma': Calcula e exibe a soma total dos valores dos produtos.\n");
    printf("Escreva 'pagar': Inicia o processo de pagamento.\n");
}


void cancelProduct(FILE **receipt, char *receiptFilename, Product *products, int *productCount) {
    printProducts(products, *productCount);
    if (*productCount > 0) {
        int itemToRemove;
        printf("Digite o n�mero do item que deseja excluir (ou 0 para cancelar a a��o): ");
        scanf("%d", &itemToRemove);

        if (itemToRemove > 0 && itemToRemove <= *productCount) {
            if (verifyCredentials()) {
                int indexToRemove = itemToRemove - 1;
                removeProduct(products, productCount, indexToRemove, receiptFilename);
            }
        } else if (itemToRemove != 0) {
            printf("N�mero inv�lido.\n");
        }
    }
}

void fim(FILE *receipt, const char *receiptFilename, Product *products, int productCount) {
    if (receipt != NULL) {
        // Finaliza o recibo
        float total = sum(products, productCount);
        fprintf(receipt, "\nTotal da compra: R$%.2f\n", total);

        // Adiciona a data e hora no recibo
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        fprintf(receipt, "\nData/Hora: %02d/%02d/%04d %02d:%02d:%02d\n",
                tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900,
                tm.tm_hour, tm.tm_min, tm.tm_sec);

        fprintf(receipt, "----------------------------------------\n");
        fclose(receipt);
        receipt = NULL;
    }

    printf("\nVenda finalizada.\n");

    // Espera 2 segundos para dar tempo de o usu�rio ver a finaliza��o
    Sleep(2000);

    // Limpa a tela
    system("cls");
    printf("Iniciando nova venda...\n");
}

void processPayment(Product *products, int productCount, FILE *receipt, const char *receiptFilename) {
    int formasPagamento = 0;
    float valorTotal = sum(products, productCount);

    receipt = fopen(receiptFilename, "a");
    if (receipt == NULL) {
        printf("Erro ao abrir o arquivo de recibo.\n");
        return;
    }

    fprintf(receipt, "\nTotal da compra: R$%.2f\n", valorTotal);

    while (formasPagamento < 1) {
        printf("\nTotal a pagar: R$%.2f\n", valorTotal);
        printf("Qual ser� a forma de pagamento? (Digite o n�mero da op��o)\n");
        printf("1) Dinheiro \n2) Cr�dito \n3) D�bito \n4) Pix\n");

        char entrada[10];
        scanf("%s", entrada);
        int opcao = atoi(entrada);

        if (opcao == 0 && entrada[0] != '0') {
            printf("Entrada inv�lida. Tente novamente.\n");
            continue;
        }

        switch (opcao) {
            case 1: {
                float dinheiroCliente, troco;
                printf("Voc� escolheu pagar com dinheiro\n");
                printf("Total da compra R$%.2f\n", valorTotal);
                printf("Inserir o valor pago pelo cliente\n");
                scanf("%s", entrada);
                dinheiroCliente = atof(entrada);

                if (dinheiroCliente == 0 && entrada[0] != '0') {
                    printf("Entrada inv�lida. Tente novamente.\n");
                    continue;
                }

                troco = dinheiroCliente - valorTotal;
                if (dinheiroCliente < valorTotal) {
                    valorTotal -= dinheiroCliente;
                    printf("Falta %.2f\n", valorTotal);
                    fprintf(receipt, "Pagamento parcial em Dinheiro: R$%.2f\n", dinheiroCliente);
                    fprintf(receipt, "Valor restante: R$%.2f\n", valorTotal);
                } else {
                    printf("Troco do cliente R$%.2f\n", troco);
                    fprintf(receipt, "Forma de pagamento: Dinheiro\n");
                    fprintf(receipt, "Valor pago: R$%.2f\n", dinheiroCliente);
                    fprintf(receipt, "Troco: R$%.2f\n", troco);
                    formasPagamento = 1;
                }
                break;
            }

            case 2: case 3: {
                printf("Voc� escolheu pagar com cart�o de %s\n", (opcao == 2) ? "cr�dito" : "d�bito");
                printf("Insira a senha de %d d�gitos do cart�o:\n", (opcao == 2) ? 6 : 4);

                int maxTentativas = 3;
                int tentativas = 0;
                char senhaCartao[10];
                int senhaCorreta = 0;

                while (tentativas < maxTentativas) {
                    printf("Senha: ");
                    int i = 0;
                    char ch;
                    while ((ch = getch()) != '\r') {
                        if (ch == '\b' && i > 0) {
                            printf("\b \b");
                            i--;
                        } else if (ch >= '0' && ch <= '9') {
                            senhaCartao[i++] = ch;
                            printf("*");
                        }
                    }
                    senhaCartao[i] = '\0';
                    printf("\n");

                    if ((opcao == 2 && i == 6) || (opcao == 3 && i == 4)) {
                        printf("Pagamento efetuado com sucesso!\n");
                        fprintf(receipt, "Forma de pagamento: %s\n", (opcao == 2) ? "Cart�o de Cr�dito" : "Cart�o de D�bito");
                        fprintf(receipt, "Valor pago: R$%.2f\n", valorTotal);
                        senhaCorreta = 1;
                        formasPagamento = 1;
                        break;
                    } else {
                        tentativas++;
                        printf("Senha incorreta. Tentativa %d de %d.\n", tentativas, maxTentativas);
                        if (tentativas == maxTentativas) {
                            printf("N�mero m�ximo de tentativas atingido.\n");
                            break;
                        }
                    }
                }
                if (!senhaCorreta) {
                    printf("Retornando � escolha de forma de pagamento.\n");
                }
                break;
            }

            case 4: {
                printf("Voc� escolheu pagar com Pix\n");
                printf("Valor total a ser pago �: R$%.2f\n", valorTotal);
                printf("A chave Pix �: pay@horticonecta.com\n");
                fprintf(receipt, "Forma de pagamento: PIX\n");
                fprintf(receipt, "Valor pago: R$%.2f\n", valorTotal);
                formasPagamento = 1;
                break;
            }

            default:
                printf("Op��o inv�lida. Tente novamente.\n");
                break;
        }
    }

    fim(receipt, receiptFilename, products, productCount);
}

int main() {
    setlocale(LC_ALL, "portuguese");

    while (1) {  // Outer loop for program restart
        char code[10];
        char receiptFilename[100];
        FILE *receipt = NULL;
        Product products[MAX_PRODUCTS];
        int productCount = 0;
        float somaResultado = 0.0;

        printf("\n=== Nova venda iniciada ===\n\n");

        while (1) {  // Inner loop for current receipt
            printf("Digite o c�digo do produto (4 d�gitos) ou 'help' para ajuda: ");
            scanf("%9s", code);

            if (strcmp(code, "pagar") == 0) {
                if (productCount > 0) {
                    processPayment(products, productCount, receipt, receiptFilename);
                    if (receipt != NULL) {
                        fclose(receipt);
                        receipt = NULL;
                    }
                    printf("\nVenda finalizada. Iniciando nova venda...\n");
                    break;  // Break inner loop to restart
                } else {
                    printf("N�o h� produtos para pagamento.\n");
                }
                continue;
            }

            if (strcmp(code, "soma") == 0) {
                somaResultado = sum(products, productCount);
                printf("Soma total dos valores: R$%.2f\n", somaResultado);
                printf("\n");
                continue;
            }

            if (strcmp(code, "cancelar") == 0) {
                cancelProduct(&receipt, receiptFilename, products, &productCount);
                printf("\n");
                continue;
            }

            if (strcmp(code, "help") == 0) {
                showHelp();
                printf("\n");
                continue;
            }

            searchProduct("../management/products-value.txt", code, &receipt, receiptFilename, products, &productCount);
            printf("\n");
        }
    }

    return 0;
}
