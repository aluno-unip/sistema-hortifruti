#include <stdio.h>
#include <string.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
#include <windows.h>

#define MAX_LINE_LENGTH 100
#define MAX_PRODUCTS 100

typedef struct {
    char description[MAX_LINE_LENGTH];
    float weightKg;
    int weightGrams;
    int quantity;
    float totalValue;
} Product;

void createInputFile(char *filename) {
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);

    sprintf(filename, "../management/control/input-%02d-%02d-%04d-%02d-%02d-%02d.txt",
            tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900,
            tm.tm_hour, tm.tm_min, tm.tm_sec);
}

void addProductToFile(const Product *product, const char *filename) {
    FILE *file = fopen(filename, "a");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo para adicionar produto.\n");
        return;
    }

    // Quando o produto tem peso
    if (product->weightGrams > 0) {
        fprintf(file, "Produto: %sPeso: %dg\n\n",
                product->description, product->weightGrams);
    }
    // Quando o produto tem quantidade
    else {
        fprintf(file, "Produto: %s\n", product->description);
        fprintf(file, "Quantidade: %d\n\n", product->quantity);  // A quantidade vai para uma linha separada
    }

    fclose(file);
}

int readProductsFromFile(const char *filename, Product *products) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        return 0;
    }

    char line[MAX_LINE_LENGTH];
    int productCount = 0;
    Product currentProduct = {0};
    int lineCount = 0;

    while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
        if (strncmp(line, "Produto: ", 9) == 0) {
            if (lineCount > 0) {
                products[productCount++] = currentProduct;
                memset(&currentProduct, 0, sizeof(Product));
            }
            strncpy(currentProduct.description, line + 9, MAX_LINE_LENGTH - 9);
            lineCount = 1;
        } else if (strstr(line, "Peso: ") != NULL) {
            sscanf(line, "Peso: %dg", &currentProduct.weightGrams);
            currentProduct.weightKg = currentProduct.weightGrams / 1000.0;
        } else if (strstr(line, "Quantidade: ") != NULL) {
            sscanf(line, "Quantidade: %d", &currentProduct.quantity);
            products[productCount++] = currentProduct;
            memset(&currentProduct, 0, sizeof(Product));
            lineCount = 0;
        }
    }

    fclose(file);
    return productCount;
}

void rewriteProductFile(const char *filename, const Product *products, int productCount) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Erro ao reescrever arquivo de produtos.\n");
        return;
    }

    for (int i = 0; i < productCount; i++) {
        if (products[i].weightGrams > 0) {
            fprintf(file, "Produto: %sPeso: %dg\n\n",
                    products[i].description, products[i].weightGrams);
        } else {
            fprintf(file, "Produto: %sQuantidade: %d\n\n",
                    products[i].description, products[i].quantity);
        }
    }

    fclose(file);
}

int searchProduct(char *filename, char *code, FILE **input, char *inputFilename, Product *products, int *productCount) {
    FILE *file = fopen(filename, "r");
    char line[MAX_LINE_LENGTH];

    if (file == NULL) {
        printf("Erro ao abrir o arquivo de produtos.\n");
        return 0;
    }

    int found = 0;
    while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
        if (strncmp(line, code, 4) == 0) {
            found = 1;

            if (*input == NULL) {
                createInputFile(inputFilename);
                *input = fopen(inputFilename, "w");
                if (*input == NULL) {
                    printf("Erro ao criar o arquivo de entrada.\n");
                    fclose(file);
                    return 0;
                }
                printf("\nArquivo de entrada criado: %s\n\n", inputFilename);
            }

            printf("Produto: %s", line + 5);

            Product newProduct = {0};
            strncpy(newProduct.description, line + 5, MAX_LINE_LENGTH);

            // Verifica se o produto � por peso ou quantidade
            if (strstr(line, "kilo") != NULL) {
                float pesoKg;
                while (1) {
                    printf("Insira o peso em kg: ");
                    if (scanf("%f", &pesoKg) == 1 && pesoKg > 0) {
                        break;
                    } else {
                        printf("Entrada inv�lida. Por favor, insira um n�mero positivo.\n");
                        while (getchar() != '\n');
                    }
                }

                newProduct.weightKg = pesoKg;
                newProduct.weightGrams = (int)(pesoKg * 1000);

                printf("Peso: %.3f kg (%dg)\n", newProduct.weightKg, newProduct.weightGrams);
            } else {
                int quantidade;
                while (1) {
                    printf("Insira a quantidade: ");
                    if (scanf("%d", &quantidade) == 1 && quantidade > 0) {
                        break;
                    } else {
                        printf("Entrada inv�lida. Por favor, insira um n�mero positivo.\n");
                        while (getchar() != '\n');
                    }
                }

                newProduct.quantity = quantidade;

                printf("Quantidade: %d\n", newProduct.quantity);
            }

            // Adiciona o produto ao vetor de produtos
            if (*productCount < MAX_PRODUCTS) {
                products[*productCount] = newProduct;
                (*productCount)++;
                addProductToFile(&newProduct, inputFilename);
            }
            break;
        }
    }

    if (!found) {
        printf("C�digo do produto n�o encontrado.\n");
    }

    fclose(file);
    return found;
}

void printProducts(Product *products, int productCount) {
    printf("\nProdutos registrados:\n");
    for (int i = 0; i < productCount; i++) {
        if (products[i].weightGrams > 0) {
            printf("%d. Descri��o: %sPeso: %.3f kg (%dg)\nValor: R$%.2f\n\n",
                    i + 1, products[i].description, products[i].weightKg,
                    products[i].weightGrams, products[i].totalValue);
        } else {
            printf("%d. Descri��o: %sQuantidade: %d\nValor: R$%.2f\n\n",
                    i + 1, products[i].description, products[i].quantity,
                    products[i].totalValue);
        }
    }
}

void removeProduct(Product *products, int *productCount, int index, const char *filename) {
    if (index < 0 || index >= *productCount) {
        printf("�ndice inv�lido.\n");
        return;
    }

    for (int i = index; i < *productCount - 1; i++) {
        products[i] = products[i + 1];
    }
    (*productCount)--;

    rewriteProductFile(filename, products, *productCount);
    printf("Produto removido com sucesso.\n");
}

float sum(Product *products, int productCount) {
    float total = 0.0;
    for (int i = 0; i < productCount; i++) {
        total += products[i].totalValue;
    }
    return total;
}

void showHelp() {
    printf("\nComandos dispon�veis:\n");
    printf("Escreva 'cancelar': Exibe a lista de produtos e permite a exclus�o de um item.\n");
    printf("Escreva 'fim': Finaliza o processo atual e inicia um novo.\n");
}

void cancelProduct(FILE **input, char *inputFilename, Product *products, int *productCount) {
    printProducts(products, *productCount);
    if (*productCount > 0) {
        int itemToRemove;
        printf("Digite o n�mero do item que deseja excluir (ou 0 para voltar): ");
        scanf("%d", &itemToRemove);

        if (itemToRemove > 0 && itemToRemove <= *productCount) {
            int indexToRemove = itemToRemove - 1;
            removeProduct(products, productCount, indexToRemove, inputFilename);
        } else if (itemToRemove != 0) {
            printf("N�mero inv�lido.\n");
        }
    }
}

void fim(FILE *input, const char *inputFilename, Product *products, int productCount) {
    if (input != NULL) {
        // Adiciona os dados dos produtos no arquivo
        for (int i = 0; i < productCount; i++) {
            if (products[i].weightGrams > 0) {
                fprintf(input, "Produto: %sPeso: %dg\n\n",
                        products[i].description, products[i].weightGrams);
            } else {
                fprintf(input, "Produto: %sQuantidade: %d\n\n",
                        products[i].description, products[i].quantity);
            }
        }

        // Adiciona a data/hora de finaliza��o no arquivo
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        fprintf(input, "\nData/Hora: %02d/%02d/%04d %02d:%02d:%02d\n",
                tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900,
                tm.tm_hour, tm.tm_min, tm.tm_sec);

        fprintf(input, "----------------------------------------\n");
        fclose(input);
    }

    printf("\nProcesso finalizado.\n");
    Sleep(2000);
    system("cls");
    printf("Iniciando novo processo...\n");
}

int main() {
    setlocale(LC_ALL, "portuguese");

    while (1) {
        char code[10];
        char inputFilename[100];
        FILE *input = NULL;
        Product products[MAX_PRODUCTS];
        int productCount = 0;

        printf("\n=== Novo processo iniciado ===\n\n");
        printf(" ATEN��O: O peso � adcionado em kilo (1000g)!\n");
        printf(" \n");


        while (1) {
            printf("Digite o c�digo do produto (4 d�gitos) ou 'help' para ajuda: ");
            scanf("%9s", code);

            if (strcmp(code, "fim") == 0) {
                fim(input, inputFilename, products, productCount);
                break;
            }

            if (strcmp(code, "cancelar") == 0) {
                cancelProduct(&input, inputFilename, products, &productCount);
                printf("\n");
                continue;
            }

            if (strcmp(code, "help") == 0) {
                showHelp();
                printf("\n");
                continue;
            }

            searchProduct("../management/products-value.txt", code, &input, inputFilename, products, &productCount);
            printf("\n");
        }
    }

    return 0;
}
