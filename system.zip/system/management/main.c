#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <ctype.h>
#include <time.h>
#include <locale.h>


#define MAX_LINE_LENGTH 1024
#define CONTROL_FOLDER "control/"
#define STOCK_FOLDER "stock/"

int verifyCredentials() {
    const char *ID = "654321";      // ID fixo
    const char *password = "4321";  // Senha fixa
    char inputID[10];
    char inputPassword[10];
    int attempts = 0;

    while (attempts < 3) {  // Permite at� 3 tentativas
        printf("\n");
        printf(" Insira o ID: ");
        scanf("%s", inputID);  // L� o ID inserido pelo usu�rio
        printf(" Insira a senha: ");

        int i = 0;
        char ch;
        while ((ch = getch()) != '\r') {  // L� a senha sem exibi-la na tela
            if (ch == '\b') {  // Se pressionar Backspace, apaga o �ltimo caractere
                if (i > 0) {
                    printf("\b \b");
                    i--;
                }
            } else {
                inputPassword[i++] = ch;  // Armazena cada caractere digitado
                printf("*");  // Exibe '*' para cada caractere digitado
            }
        }
        inputPassword[i] = '\0';  // Finaliza a string da senha
        printf("\n");

        // Verifica se o ID e a senha est�o corretos
        if (strcmp(inputID, ID) == 0 && strcmp(inputPassword, password) == 0) {
            return 1;  // Retorna 1 se as credenciais forem corretas
        } else {
            printf("Credenciais incorretas. Tente novamente.\n");
            attempts++;  // Incrementa o contador de tentativas
        }
    }
    printf("N�mero m�ximo de tentativas atingido. A��o cancelada.\n");
    return 0;  // Retorna 0 se as credenciais forem incorretas ap�s 3 tentativas
}

// Fun��o para extrair nomes de produtos do arquivo products.txt
void extract_product_names(const char *filename, int product_codes[], char products[][100], char units[][10], int *product_count) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror(" Erro ao abrir o arquivo products.txt");
        exit(1);
    }

    char line[MAX_LINE_LENGTH];
    while (fgets(line, sizeof(line), file)) {
        int code;
        char name[100];
        char unit[10];

        if (sscanf(line, "%4d %s %s", &code, name, unit) == 3) {
            product_codes[*product_count] = code;
            strcpy(products[*product_count], name);
            strcpy(units[*product_count], unit);
            (*product_count)++;
        }
    }
    fclose(file);
}

// Fun��o para calcular o total de produtos por categoria espec�fica (tag)
// Fun��o para calcular o total de produtos por categoria espec�fica (tag)
long sum_weights_by_tag(int product_code, const char *product_name, const char *unit, const char *tag_filter) {
    DIR *dir = opendir(CONTROL_FOLDER);
    if (!dir) {
        perror("Erro ao abrir a pasta control");
        exit(1);
    }

    struct dirent *entry;
    long total = 0;

    while ((entry = readdir(dir)) != NULL) {
        if (strncmp(entry->d_name, "report", 6) == 0 && strstr(entry->d_name, ".txt")) {
            char file_path[256];
            snprintf(file_path, sizeof(file_path), "%s%s", CONTROL_FOLDER, entry->d_name);

            FILE *file = fopen(file_path, "r");
            if (!file) {
                perror("Erro ao abrir o arquivo report");
                continue;
            }

            char line[MAX_LINE_LENGTH];
            while (fgets(line, sizeof(line), file)) {
                int code;
                char prodName[100], unitType[10], tag[20];
                long value;

                if ((sscanf(line, "%4d %s %s qtd:%ld %s", &code, prodName, unitType, &value, tag) == 5 ||
                     sscanf(line, "%4d %s %s peso:%ldg %s", &code, prodName, unitType, &value, tag) == 5) &&
                    strcmp(prodName, product_name) == 0 && strcmp(tag, tag_filter) == 0) {
                    total += value;
                }
            }

            fclose(file);
        }
    }

    closedir(dir);
    return total;
}


// Fun��o para calcular o total geral (sem filtro)
long sum_weights(int product_code, const char *product_name, const char *unit) {
    DIR *dir = opendir(CONTROL_FOLDER);
    if (!dir) {
        perror(" Erro ao abrir a pasta control");
        exit(1);
    }

    struct dirent *entry;
    long total = 0;

    while ((entry = readdir(dir)) != NULL) {
        if (strncmp(entry->d_name, "receipt", 7) == 0 && strstr(entry->d_name, ".txt")) {
            char file_path[256];
            snprintf(file_path, sizeof(file_path), "%s%s", CONTROL_FOLDER, entry->d_name);

            FILE *file = fopen(file_path, "r");
            if (!file) {
                perror("Erro ao abrir o arquivo receipt");
                continue;
            }

            char line[MAX_LINE_LENGTH];
            while (fgets(line, sizeof(line), file)) {
                if (strstr(line, product_name)) {
                    while (fgets(line, sizeof(line), file)) {
                        if (strstr(line, "Peso:") || strstr(line, "Quantidade:")) {
                            long value;
                            if (sscanf(line, "Peso: %ldg", &value) == 1 || sscanf(line, "Quantidade: %ld", &value) == 1) {
                                total += value;
                            }
                            break;
                        }
                    }
                }
            }
            fclose(file);
        }
    }

    closedir(dir);
    return total;
}

// Nova fun��o para formatar n�meros com ponto a cada 3 d�gitos
void format_number(char *output, long number) {
    char temp[20];
    int len, pos = 0, count = 0;

    // Converte o n�mero para string
    sprintf(temp, "%ld", number);
    len = strlen(temp);

    // Copia os d�gitos, adicionando pontos
    for (int i = len - 1; i >= 0; i--) {
        if (count == 3 && i != 0) {
            output[pos++] = '.';
            count = 0;
        }
        output[pos++] = temp[i];
        count++;
    }
    output[pos] = '\0';

    // Inverte a string
    for (int i = 0, j = pos - 1; i < j; i++, j--) {
        char temp = output[i];
        output[i] = output[j];
        output[j] = temp;
    }
}


// Fun��o para calcular o total de entrada de produtos (input)
long sum_input_weights(int product_code, const char *product_name, const char *unit) {
    DIR *dir = opendir(CONTROL_FOLDER);
    if (!dir) {
        perror(" Erro ao abrir a pasta control");
        exit(1);
    }

    struct dirent *entry;
    long total = 0;

    while ((entry = readdir(dir)) != NULL) {
        if (strncmp(entry->d_name, "input", 5) == 0 && strstr(entry->d_name, ".txt")) {
            char file_path[256];
            snprintf(file_path, sizeof(file_path), "%s%s", CONTROL_FOLDER, entry->d_name);

            FILE *file = fopen(file_path, "r");
            if (!file) {
                perror("Erro ao abrir o arquivo input");
                continue;
            }

            char line[MAX_LINE_LENGTH];
            while (fgets(line, sizeof(line), file)) {
                if (strstr(line, product_name)) {
                    while (fgets(line, sizeof(line), file)) {
                        if (strstr(line, "Peso:") || strstr(line, "Quantidade:")) {
                            long value;
                            if (sscanf(line, "Peso: %ldg", &value) == 1 || sscanf(line, "Quantidade: %ld", &value) == 1) {
                                total += value;
                            }
                            break;
                        }
                    }
                }
            }
            fclose(file);
        }
    }

    closedir(dir);
    return total;
}

// Fun��o para gerar o nome do arquivo de estoque
void generate_stock_filename(char *filename, size_t size) {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);

    snprintf(filename, size, STOCK_FOLDER "stock-%02d-%02d-%04d-%02d-%02d-%02d.txt",
             t->tm_mday, t->tm_mon + 1, t->tm_year + 1900, t->tm_hour, t->tm_min, t->tm_sec);
}

// Fun��o para exibir e salvar o estoque atual no arquivo
void save_all_to_file(const char output_data[][256], int output_count) {
    char filename[256];
    generate_stock_filename(filename, sizeof(filename));

    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Erro ao criar o arquivo de sa�da");
        exit(1);
    }

    // Grava todos os dados no arquivo
    for (int i = 0; i < output_count; i++) {
        fprintf(file, "%s\n", output_data[i]);
    }

    fclose(file);
    printf("\n Todos os dados foram salvos no arquivo: %s\n", filename);
}

// Nova fun��o para calcular o valor total das vendas por produto
double sum_sales_value(int product_code, const char *product_name, const char *unit) {
    DIR *dir = opendir(CONTROL_FOLDER);
    if (!dir) {
        perror("Erro ao abrir a pasta control");
        exit(1);
    }

    struct dirent *entry;
    double total_value = 0.0;

    while ((entry = readdir(dir)) != NULL) {
        if (strncmp(entry->d_name, "receipt", 7) == 0 && strstr(entry->d_name, ".txt")) {
            char file_path[256];
            snprintf(file_path, sizeof(file_path), "%s%s", CONTROL_FOLDER, entry->d_name);

            FILE *file = fopen(file_path, "r");
            if (!file) {
                perror("Erro ao abrir o arquivo receipt");
                continue;
            }

            char line[MAX_LINE_LENGTH];
            while (fgets(line, sizeof(line), file)) {
                if (strstr(line, product_name)) {
                    while (fgets(line, sizeof(line), file)) {
                        if (strstr(line, "Valor:")) {
                            double value;
                            char *ptr = strstr(line, "R$");
                            if (ptr) {
                                // Convert Brazilian currency format (e.g., "R$11,00" to float)
                                ptr += 2; // Skip "R$"
                                char clean_value[32];
                                int j = 0;
                                for (int i = 0; ptr[i] != '\0'; i++) {
                                    if (isdigit(ptr[i]) || ptr[i] == ',') {
                                        if (ptr[i] == ',') {
                                            clean_value[j] = '.';
                                        } else {
                                            clean_value[j] = ptr[i];
                                        }
                                        j++;
                                    }
                                }
                                clean_value[j] = '\0';
                                value = atof(clean_value);
                                total_value += value;
                            }
                            break;
                        }
                    }
                }
            }
            fclose(file);
        }
    }

    closedir(dir);
    return total_value;
}

// Function to check low stock and display supplier information
// Function to check low stock and display supplier information
void check_low_stock(int product_codes[], char products[][100], char units[][10], int product_count) {
    FILE *suppliers = fopen("suppliers.txt", "r");
    if (!suppliers) {
        perror("Error opening suppliers.txt");
        return;
    }

    printf("\n Fornecedores dos Produtos com Baixo Estoque (abaixo de 250 kg/unid):\n");

    for (int i = 0; i < product_count; i++) {
        long total_entrada = sum_input_weights(product_codes[i], products[i], units[i]);
        long total_venda = sum_weights(product_codes[i], products[i], units[i]);
        long total_promocao = sum_weights_by_tag(product_codes[i], products[i], units[i], "promocao");
        long total_doacao = sum_weights_by_tag(product_codes[i], products[i], units[i], "doacao");
        long total_descarte = sum_weights_by_tag(product_codes[i], products[i], units[i], "descarte");

        long total_saida = total_venda + total_promocao + total_doacao + total_descarte;
        long estoque_atual = total_entrada - total_saida;

        if (strcmp(units[i], "kilo") == 0) {
            estoque_atual /= 1000; // Convert grams to kg
        }

        if (estoque_atual < 250) {
            char supplier_line[MAX_LINE_LENGTH];
            int found = 0;

            rewind(suppliers);

            while (fgets(supplier_line, sizeof(supplier_line), suppliers)) {
                int sup_code;
                if (sscanf(supplier_line, "%d", &sup_code) == 1) {
                    if (sup_code == product_codes[i]) {
                        printf("\n%s", supplier_line);
                        found = 1;
                        break;
                    }
                }
            }

            if (!found) {
                printf("Nenhum fornecedor encontrado para o c�digo: %04d\n", product_codes[i]);
            }
        }
    }

    fclose(suppliers);
}

int main() {
    setlocale(LC_ALL, "portuguese");
    time_t now = time(NULL);
    struct tm *t = localtime(&now);

        if (!verifyCredentials()) {
        return 1; // Encerra o programa se o login falhar
    }

    printf(" \n");
    printf(" Login de Gerente Realizado com Sucesso!\n");


    // Array para armazenar todos os dados exibidos no console
    char output_data[1000][256]; // At� 1000 linhas de sa�da (ajust�vel)
    int output_count = 0;

    char products[100][100];
    char units[100][10];
    int product_codes[100];
    int product_count = 0;

    extract_product_names("products.txt", product_codes, products, units, &product_count);

    // Exibindo e armazenando o t�tulo
    char header[256];
    printf("%s\n", header);
    snprintf(header, sizeof(header), " Relat�rio Gest�o - %02d-%02d-%04d:\n", t->tm_mday, t->tm_mon + 1, t->tm_year + 1900);
    printf("%s\n", header);
    strncpy(output_data[output_count++], header, sizeof(header));

    // Estoque Atual
    snprintf(header, sizeof(header), "\n Estoque Atual:\n");
    printf("%s", header);
    strncpy(output_data[output_count++], header, sizeof(header));

    for (int i = 0; i < product_count; i++) {
        long total_entrada = sum_input_weights(product_codes[i], products[i], units[i]);
        long total_venda = sum_weights(product_codes[i], products[i], units[i]);
        long total_promocao = sum_weights_by_tag(product_codes[i], products[i], units[i], "promocao");
        long total_doacao = sum_weights_by_tag(product_codes[i], products[i], units[i], "doacao");
        long total_descarte = sum_weights_by_tag(product_codes[i], products[i], units[i], "descarte");

        long total_saida = total_venda + total_promocao + total_doacao + total_descarte;
        long estoque_atual = total_entrada - total_saida;

        char line[256];
        if (strcmp(units[i], "kilo") == 0) {
            char formatted_number[20];
            if (estoque_atual < 1000) {
                format_number(formatted_number, estoque_atual);
                snprintf(line, sizeof(line), "  %04d - %s - %s g", product_codes[i], products[i], formatted_number);
            } else {
                format_number(formatted_number, estoque_atual / 1000);
                snprintf(line, sizeof(line), "  %04d - %s - %s kg", product_codes[i], products[i], formatted_number);
            }
        } else {
            snprintf(line, sizeof(line), "  %04d - %s - %ld unid", product_codes[i], products[i], estoque_atual);
        }

        printf("%s\n", line);
        strncpy(output_data[output_count++], line, sizeof(line));
    }

    // Valor Total de Vendas
    snprintf(header, sizeof(header), "\n Valor Total de Vendas:\n");
    printf("%s", header);
    strncpy(output_data[output_count++], header, sizeof(header));

    double total_vendas = 0.0;
    for (int i = 0; i < product_count; i++) {
        double valor_vendas = sum_sales_value(product_codes[i], products[i], units[i]);
        total_vendas += valor_vendas;
        char line[256];
        snprintf(line, sizeof(line), "  %04d - %s - R$%.2f", product_codes[i], products[i], valor_vendas);
        printf("%s\n", line);
        strncpy(output_data[output_count++], line, sizeof(line));
    }
    snprintf(header, sizeof(header), "\n  Faturamento Total Loja: R$%.2f\n", total_vendas);
    printf("%s", header);
    strncpy(output_data[output_count++], header, sizeof(header));

// Tags Espec�ficas (Promo��o, Doa��o, Descarte)
const char *tags[] = {"promocao", "doacao", "descarte"};
for (int k = 0; k < 3; k++) {
    snprintf(header, sizeof(header), "\n%s:\n", tags[k]);
    printf("%s", header);
    strncpy(output_data[output_count++], header, sizeof(header));

    for (int i = 0; i < product_count; i++) {
        long total_categoria = sum_weights_by_tag(product_codes[i], products[i], units[i], tags[k]);

        char line[256];
        if (strcmp(units[i], "kilo") == 0) {
            if (total_categoria < 1000) {
                char formatted_number[20];
                format_number(formatted_number, total_categoria);
                snprintf(line, sizeof(line), "  %04d - %s - %s g", product_codes[i], products[i], formatted_number);
            } else {
                char formatted_number[20];
                format_number(formatted_number, total_categoria / 1000);
                snprintf(line, sizeof(line), "  %04d - %s - %s kg", product_codes[i], products[i], formatted_number);
            }
        } else {
            snprintf(line, sizeof(line), "  %04d - %s - %ld unid", product_codes[i], products[i], total_categoria);
        }

        printf("%s\n", line);
        strncpy(output_data[output_count++], line, sizeof(line));
    }
}

    check_low_stock(product_codes, products, units, product_count);
    // Salva todos os dados no arquivo
    save_all_to_file(output_data, output_count);

    printf("\n Pressione qualquer tecla para sair...\n");
    getchar(); // Espera pelo Enter caso j� tenha entrada no buffer
    getchar(); // Aguarda o usu�rio pressionar uma tecla

    return 0;
}
