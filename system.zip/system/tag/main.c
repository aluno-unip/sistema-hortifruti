#include <stdio.h>
#include <string.h>
#include <locale.h>
#include <time.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h> // suco

#define MAX_LINE_LENGTH 100
#define MAX_PRODUCTS 100

typedef struct {
    char description[MAX_LINE_LENGTH];
    char name[50];
    int quantity;
    int weight;
} Product;

void createNewReport(FILE **report, char *reportFilename) {
    // If there's an existing report, close it first
    if (*report != NULL) {
        // Add final timestamp to previous report
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        fprintf(*report, "\nData/Hora: %02d/%02d/%04d %02d:%02d:%02d\n",
                tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900,
                tm.tm_hour, tm.tm_min, tm.tm_sec);
        fprintf(*report, "----------------------------------------\n");
        fclose(*report);
        *report = NULL;
    }

    // Create report directory if it doesn't exist
    system("mkdir report 2> nul");

    // Create new report filename with timestamp
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(reportFilename, "../management/control/report-%02d-%02d-%04d-%02d-%02d-%02d.txt",
            tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900,
            tm.tm_hour, tm.tm_min, tm.tm_sec);

    // Open new report file
    *report = fopen(reportFilename, "w");
    if (*report == NULL) {
        printf("Erro ao criar o arquivo de relat�rio.\n");
        return;
    }
    printf("\nNovo arquivo de relat�rio criado: %s\n\n", reportFilename);
}

// Function to add product to file
void addProductToFile(const Product *product, const char *filename) {
    FILE *file = fopen(filename, "a");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo para adicionar produto.\n");
        return;
    }

    if (product->weight > 0) {
        fprintf(file, "Produto: %s_Peso: %dg\n\n",
                product->description, product->weight);
    } else {
        fprintf(file, "Produto: %s_Quantidade: %d\n\n",
                product->description, product->quantity);
    }

    fclose(file);
}

// Function to read products from file
int readProductsFromFile(const char *filename, Product *products) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        return 0;
    }

    char line[MAX_LINE_LENGTH];
    int productCount = 0;
    Product currentProduct = {0};
    int lineCount = 0;

    while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
        if (strncmp(line, "Produto: ", 9) == 0) {
            if (lineCount > 0) {
                products[productCount++] = currentProduct;
                memset(&currentProduct, 0, sizeof(Product));
            }
            strncpy(currentProduct.description, line + 9, MAX_LINE_LENGTH - 9);

            // Remover nova linha mantendo o '_'
            char *newline = strchr(currentProduct.description, '\n');
            if (newline) *newline = '\0';

            lineCount = 1;
        } else if (strstr(line, "Peso: ") != NULL) {
            sscanf(line, "Peso: %dg", &currentProduct.weight);
        } else if (strstr(line, "Quantidade: ") != NULL) {
            sscanf(line, "Quantidade: %d", &currentProduct.quantity);
        }
    }

    if (lineCount > 0) {
        products[productCount++] = currentProduct;
    }

    fclose(file);
    return productCount;
}

// Function to rewrite file with updated products
void rewriteProductFile(const char *filename, const Product *products, int productCount) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Erro ao reescrever arquivo de produtos.\n");
        return;
    }

    for (int i = 0; i < productCount; i++) {
        if (products[i].weight > 0) {
            fprintf(file, "Produto: %s_Peso: %dg\n\n",
                    products[i].description, products[i].weight);
        } else {
            fprintf(file, "Produto: %s_Quantidade: %d\n\n",
                    products[i].description, products[i].quantity);
        }
    }

    fclose(file);
}

int getValidIntegerInput(const char *prompt) {
    char input[MAX_LINE_LENGTH];
    int value;
    int result;
    int firstAttempt = 1;

    while (1) {
        if (firstAttempt) {
            printf("%s", prompt);
            firstAttempt = 0;
        } else {
            printf("Insira o peso (gramas) ou quantidade com n�mero inteiro: %s", prompt);
        }

        if (fgets(input, MAX_LINE_LENGTH, stdin) == NULL) {
            printf("Erro ao ler a entrada. Tente novamente.\n");
            continue;
        }

        // Remove newline character
        input[strcspn(input, "\n")] = 0;

        // Check for help command
        if (strcmp(input, "help") == 0) {
            showHelp();
            printf("\n");  // Add a newline for better formatting
            firstAttempt = 1;  // Reset to show original prompt
            continue;
        }

        // Validate numeric input
        int isValid = 1;
        for (int i = 0; i < strlen(input); i++) {
            if (input[i] == ',' || input[i] == '.' || !isdigit(input[i])) {
                isValid = 0;
                break;
            }
        }

        if (!isValid) {
            continue;
        }

        result = sscanf(input, "%d", &value);
        if (result == 1) {
            return value;
        }
    }
}

// Fun��o suco
int containsSuco(const char *line);

// Implementa��o da fun��o
int containsSuco(const char *line) {
    const char *suco = "Suco";
    int len = strlen(suco);
    int i;

    // Itera pela linha verificando se "suco" aparece
    for (i = 0; line[i] != '\0'; i++) {
        if (strncmp(&line[i], suco, len) == 0) {
            return 1; // "suco" encontrado
        }
    }
    return 0; // "suco" n�o encontrado
}


// Fun��o de pesquisa de produto
int searchProduct(char *filename, char *code, FILE **report, char *reportFilename, Product *products, int *productCount) {
    FILE *file = fopen(filename, "r");
    char line[MAX_LINE_LENGTH];

    if (strcmp(code, "help") == 0) {
        showHelp();
        return 0;
    }

    if (file == NULL) {
        printf("Erro ao abrir o arquivo de produtos.\n");
        return 0;
    }

    int found = 0;
    while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
        if (strncmp(line, code, 4) == 0) {
            found = 1;

            // Cria novo relat�rio para cada c�digo de produto v�lido
            createNewReport(report, reportFilename);
            if (*report == NULL) {
                fclose(file);
                return 0;
            }

            printf("Produto: %s", line + 5);

            // Cria��o de novo produto
            Product newProduct = {0};
            strncpy(newProduct.description, line + 5, MAX_LINE_LENGTH);

            // Remove a nova linha da descri��o, caso exista
            char *newline = strchr(newProduct.description, '\n');
            if (newline) *newline = '\0';

            // Obt�m peso ou quantidade primeiro
            if (strstr(line, "kilo") != NULL) {
                // Agora, solicita o peso e valida a entrada
                int peso = getValidIntegerInput("");
                newProduct.weight = peso;

                // Agora, inicia o question�rio e obt�m a tag
                char tag[20] = "";
                processQuestionnaire(1, tag); // 1 para produtos a granel

                // Salva no arquivo de relat�rio - tudo em uma linha
                fprintf(*report, "%s %s peso:%dg %s\n",
                        code, newProduct.description, peso, tag);

                // Exibe a mensagem de resultado com base na tag
                displayResultMessage(tag);

            } else {
                // Agora, solicita a quantidade e valida a entrada
                int quantidade = getValidIntegerInput("");
                newProduct.quantity = quantidade;

                // Determina se � uma bebida ou produto embalado
                int productClass = containsSuco(line) ? 3 : 2;



                // Agora, inicia o question�rio e obt�m a tag
                char tag[20] = "";
                processQuestionnaire(productClass, tag);

                // Salva no arquivo de relat�rio - tudo em uma linha
                fprintf(*report, "%s %s qtd:%d %s\n",
                        code, newProduct.description, quantidade, tag);

                // Exibe a mensagem de resultado com base na tag
                displayResultMessage(tag);
            }

            // Adiciona ao array de produtos
            if (*productCount < MAX_PRODUCTS) {
                products[*productCount] = newProduct;
                (*productCount)++;
            }

            // Chama a fun��o fim
            fim(*report, reportFilename, products, *productCount);
            break;
        }
    }

    if (!found) {
        printf("C�digo do produto n�o encontrado.\n");
    }

    fclose(file);
    return found;
}

void getValidInput(char *resposta) {
    char input[256];
    int valid;
    char currentPrompt[256] = "";  // Default prompt

    do {
        valid = 1;
        printf("%s", currentPrompt);

        if (fgets(input, sizeof(input), stdin) != NULL) {
            // Remove newline character
            input[strcspn(input, "\n")] = 0;

            // Check for help command
            if (strcmp(input, "help") == 0) {
                showHelp();
                printf("\n%s", currentPrompt);  // Repeat the current prompt
                valid = 0;
                continue;
            }

            // Check for single character 's' or 'n'
            if (strlen(input) != 1) {
                printf("Erro: Digite apenas um caractere ('s' ou 'n'):\n");
                valid = 0;
                continue;
            }

            if (input[0] != 's' && input[0] != 'n') {
                printf("Erro: Resposta inv�lida.\n");
                valid = 0;
                continue;
            }

            *resposta = input[0];

        } else {
            printf("Erro de leitura.\n");
            valid = 0;
            if (ferror(stdin)) {
                clearerr(stdin);
            }
        }
    } while (!valid);
}

void processQuestionnaire(int productClass, char *tag) {
    char dentroValidade, resposta, proximoVencimento;
    printf("\nIniciando question�rio de avalia��o:\n");
    printf("O produto est� dentro do prazo de validade? (s/n): ");
    getValidInput(&dentroValidade);
    if (dentroValidade != 's') {
        strcpy(tag, "descarte");
        return;
    }
    switch (productClass) {
        case 1: // Bulk products
            printf("O produto apresenta podrid�o, pragas ou danos severos? (s/n): ");
            getValidInput(&resposta);
            if (resposta == 's') {
                strcpy(tag, "descarte");
            } else {
                printf("O produto est� levemente danificado ou com manchas? (s/n): ");
                getValidInput(&resposta);
                if (resposta == 's') {
                    strcpy(tag, "promocao");
                } else {
                    strcpy(tag, "loja");
                }
            }
            break;
        case 2: // Packaged products
            printf("A embalagem est� intacta? (s/n): ");
            getValidInput(&resposta);
            if (resposta == 's') {
                strcpy(tag, "loja");
            } else {
                printf("O conte�do interno est� intacto? (s/n): ");
                getValidInput(&resposta);
                if (resposta == 's') {
                    strcpy(tag, "doacao");
                } else {
                    strcpy(tag, "descarte");
                }
            }
            break;
case 3: // Drinks
    printf("O lacre est� intacto? (s/n): ");
    getValidInput(&resposta);
    if (resposta == 'n') {
        strcpy(tag, "descarte");
    } else {
        printf("O produto est� pr�ximo do vencimento? (s/n): ");
        getValidInput(&proximoVencimento);
        if (proximoVencimento == 'n') {
            strcpy(tag, "loja");
        } else {
            strcpy(tag, "promocao");
        }
    }
    break;


    }
}

void displayResultMessage(const char *tag) {
    printf("\nRESULTADO DA AVALIA��O:\n");
    printf("------------------------\n");
    if (strcmp(tag, "loja") == 0) {
        printf("LOJA: O produto est� apropriado para venda na loja.\n");
    } else if (strcmp(tag, "promocao") == 0) {
        printf("PROMO��O: O produto deve ser colocado em promo��o.\n");
    } else if (strcmp(tag, "doacao") == 0) {
        printf("DOA��O: O produto deve ser destinado para doa��o.\n");
    } else if (strcmp(tag, "descarte") == 0) {
        printf("DESCARTE: O produto deve ser descartado.\n");
    }
    printf("------------------------\n\n");
}

void showHelp() {
    printf("\n=== Dicas Para Responder ===\n");
    printf("1. 30 dias at� o fim da validade � pr�ximo do fim da validade.\n");
    printf("2. Gotas grandes nas hortali�as pode significar mal armazenamento e menor validade.\n");
    printf("3. Textura diferente do padr�o n�o � um bom sinal.\n");

}

void fim(FILE *report, const char *reportFilename, Product *products, int productCount) {
    if (report != NULL) {
        // Finaliza o relat�rio

        // Adiciona a data e hora no relat�rio
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        fprintf(report, "\nData/Hora: %02d/%02d/%04d %02d:%02d:%02d\n",
                tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900,
                tm.tm_hour, tm.tm_min, tm.tm_sec);

        fprintf(report, "----------------------------------------\n");
        fclose(report);
        report = NULL;
    }

    printf("\nGest�o de Produtos finalizada.\n");

    // Espera 2 segundos para dar tempo de o usu�rio ver a finaliza��o
    Sleep(3000);

    // Limpa a tela
    system("cls");
    printf("Iniciando nova venda...\n");
}

int main() {
    setlocale(LC_ALL, "portuguese");

    while (1) {  // Outer loop for program restart
        char code[10];
        char reportFilename[100];
        FILE *report = NULL;
        Product products[MAX_PRODUCTS];
        int productCount = 0;

        printf("\n=== Definir categoria de Produtos ===\n\n");

        while (1) {  // Inner loop for current report
            printf("Digite o c�digo do produto (4 d�gitos) ou 'help' para ajuda: ");
            scanf("%9s", code);

            //comando secreto que era utilizado para testes

            if (strcmp(code, "fim98") == 0) {
                if (report != NULL) {
                    fclose(report);
                    report = NULL;
                }
                printf("Fim da Gest�o de Produtos.\n");

                // Atraso de 2 segundos antes de limpar a tela
                Sleep(20000);

                printf("Iniciando nova Gest�o de Produtos...\n");

                // Limpar a tela usando 'cls' no Windows
                system("cls");

                break;  // Sai do loop interno e inicia uma nova venda
            }

            if (strcmp(code, "help") == 0) {
                showHelp();
                printf("\n");
                continue;
            }

            searchProduct("../management/products-kg.txt", code, &report, reportFilename, products, &productCount);
            printf("\n");
        }
    }

    return 0;
}
